<?php
/**
 * 这是皮卡苏写的的一套主题。你可以联系<a href="http://tool.gljlw.com/qq/?qq=3238014903">作者QQ</a> <a href="https://github.com/tianqi110/Purple-Butterfly">项目地址</a>获得更多关于此主题的信息
 * 
 * @package Purple-Butterfly
 * @author 皮卡苏
 * @version 1.0.0
 * @link http://tool.gljlw.com/qq/?qq=3238014903
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<div class="col-mb-12 col-8" id="main" role="main">
	<?php while($this->next()): ?>
        <article class="post" itemscope itemtype="http://schema.org/BlogPosting">
			<h2 class="post-title" itemprop="name headline"><a itemprop="url" href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
			<ul class="post-meta">
				<li itemprop="author" itemscope itemtype="http://schema.org/Person"><?php _e(''); ?><a itemprop="name" href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></li>
				<li><?php _e('时间: '); ?><time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date(); ?></time></li>
				<li><?php _e(''); ?><?php $this->category(','); ?></li>
				<li itemprop="interactionCount"><a itemprop="discussionUrl" href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('无评论', '1 条评论', '%d 条评论'); ?></a></li>
			</ul>
            <div class="post-content" itemprop="articleBody">
				<div class="post-content-top">
					<a itemprop="url" href="<?php $this->permalink() ?>">
					<img src="<?php echo img_postthumb($this); ?>">
					</a>
					<span class="post-content-top-views"><?php get_post_view($this) ?>阅读</span>
				</div>
    			<p class="post-content-botoom">
					<?php $this->excerpt(100,'  ...'); ?>
					</p>
				
				<div class="post-content-sub">
					
					<a itemprop="url" href="<?php $this->permalink() ?>"><button type="button" class="post-content-submit">阅读更多</button></a>
				</div>
        </article>
	<?php endwhile; ?>


    <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
</div><!-- end #main-->

<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>
