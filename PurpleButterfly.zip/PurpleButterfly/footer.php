<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

        </div><!-- end .row -->
    </div>
</div><!-- end #body -->

<footer id="footer" role="contentinfo">
    &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>.
    <?php _e('由 <a href="http://www.typecho.org">Typecho</a> & <a href="https://github.com/tianqi110/Purple-Butterfly">Purple-Butterfly</a>'); ?>.
</footer><!-- end #footer -->	
<?php $this->footer(); ?>

<!--代码高亮-->
<script>
//这个是开启行号
$("pre").addClass("line-numbers").css("white-space", "pre-wrap");



<script type="text/javascript" src="prism.js"></script>
<script>hljs.initHighlightingOnLoad();</script>
<script type="text/javascript">
$(document).on('pjax:complete', function() {
    document.querySelectorAll('pre code').forEach((block) => {
    hljs.highlightBlock(block);
    });
});
</script>
<!-- 灯箱 -->
<script type="text/javascript">
    $(document).ready(function () {
        $( ".fancybox").fancybox();
    });
</script>


</body>
</html>
