<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
		
		<!--代码高亮-->
		<link rel="stylesheet" href="<?php $this->options->themeUrl('prism.css');?>" />
		<script src="<?php $this->options->themeUrl('prism.js');?>"></script>
    <!-- 使用url函数转换相关路径 -->
    <link rel="stylesheet" href="//cdnjscn.b0.upaiyun.com/libs/normalize/2.1.3/normalize.min.css">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('grid.css'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <!--[if lt IE 9]>
    <script src="//cdnjscn.b0.upaiyun.com/libs/html5shiv/r29/html5.min.js"></script>
    <script src="//cdnjscn.b0.upaiyun.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header(); ?>
	<!-- 引用 FancyBox插件 -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script> <!--如果主题已经引用了jQuery库，可以忽略这条-->
	<link rel="stylesheet" href="https://cdn.staticfile.org/fancybox/3.5.2/jquery.fancybox.min.css">
	<script src="https://cdn.staticfile.org/fancybox/3.5.2/jquery.fancybox.min.js"></script>

</head>
<body>
<!--[if lt IE 8]>
    <div class="browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="http://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
<![endif]-->

<header id="header" class="clearfix">
    <div class="container">
        <div class="row">
			<!--顶部导航栏-->
		<div class="row-top">
			<!--侧边栏-->
			<div class="sidebar">
				 <input type='checkbox' id='sidemenu'>
						<aside>
						<div class="author">
							
				           <div class="author-logo">
							<?php $email=$comments->mail; $imgUrl = getGravatar($email);echo '<img src="'.$imgUrl.'" width="45px" height="45px" style="border-radius: 50%;" >'; ?>
							 </div>
							 <a href="<?php $this->author->permalink(); ?>">
							 <p class="author-name" ><?php $this->author() ?></p>
							 </a>
							 <span class="author-bottom">
							<p>已发布 <?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?><?php $stat->publishedPostsNum() ?>
							篇文章</p>
							 </span>
						 </div>
							<br />
							<!--输出分类-->
				            <ul id="sideul">
				               <?php $this->widget('Widget_Metas_Category_List')
				               		               ->parse('<li><a href="{permalink}">{name}</a></li>'); ?>
				            </ul>
							<!--输出标签云-->
							<div class="author">
								 <span class="author-bottom">
									 <p>标签云</p>
								<?php $this->widget('Widget_Metas_Tag_Cloud', 'ignoreZeroCount=0&limit=18')->to($tags); ?>
								<ul class="tags-list">
								<?php while($tags->next()): ?>
								    <li><a style="color: rgb(<?php echo(rand(0, 255)); ?>, <?php echo(rand(0,255)); ?>, <?php echo(rand(0, 255)); ?>)" href="<?php $tags->permalink(); ?>" title='<?php $tags->name(); ?>'><?php $tags->name(); ?></a></li>
								<?php endwhile; ?>
								</ul>
								 </span>
							 </div>
				        </aside>
					
				        <div id='wrap'>
				            <label id='sideMenuControl' for='sidemenu'>
								<div class="cbllogo">
								
								 <svg t="1610198168172" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3929" width="16" height="16"><path d="M892.8-490.73066659H960v64h64v67.2h-64v60.16h-67.2v-60.16H832V-426.73066659h60.8z" fill="#7D8099" p-id="3930"></path><path d="M0 467.136h1024v89.6H0z" fill="#407CD5" p-id="3931"></path><path d="M511.99969973 21.33364848h0.00060054c0.00000794 0 0.00001483-0.00000689 0.00001483-0.00001537V21.33342344H512.00037072v0.00020967c0 0.00003918-0.00003177 0.00007096-0.00007044 0.00007096H511.99969973c-0.00003865 0-0.00007043-0.00003177-0.00007045-0.00007096V21.33342344h0.00005562v0.00020967c0 0.00000847 0.00000689 0.00001537 0.00001483 0.00001536zM512.00031511 21.33312098H512.00037072v0.00012229h-0.00005561zM511.99969973 21.33296264H512.00021184v0.00005561H511.99969973c-0.00000794 0-0.00001483 0.00000689-0.00001483 0.00001483v0.0002102H511.99962928V21.33303308c0-0.00003918 0.00003177-0.00007043 0.00007044-0.00007044z" fill="#7D8099" p-id="3932"></path></svg>
								  <svg t="1610198168172" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3929" width="16" height="16"><path d="M892.8-490.73066659H960v64h64v67.2h-64v60.16h-67.2v-60.16H832V-426.73066659h60.8z" fill="#7D8099" p-id="3930"></path><path d="M0 467.136h1024v89.6H0z" fill="#407CD5" p-id="3931"></path><path d="M511.99969973 21.33364848h0.00060054c0.00000794 0 0.00001483-0.00000689 0.00001483-0.00001537V21.33342344H512.00037072v0.00020967c0 0.00003918-0.00003177 0.00007096-0.00007044 0.00007096H511.99969973c-0.00003865 0-0.00007043-0.00003177-0.00007045-0.00007096V21.33342344h0.00005562v0.00020967c0 0.00000847 0.00000689 0.00001537 0.00001483 0.00001536zM512.00031511 21.33312098H512.00037072v0.00012229h-0.00005561zM511.99969973 21.33296264H512.00021184v0.00005561H511.99969973c-0.00000794 0-0.00001483 0.00000689-0.00001483 0.00001483v0.0002102H511.99962928V21.33303308c0-0.00003918 0.00003177-0.00007043 0.00007044-0.00007044z" fill="#7D8099" p-id="3932"></path></svg>
								  </div>
							</label>
				            <!--for 属性规定 label 与哪个表单元素绑定，即将这个控制侧边栏进出的按钮与checkbox绑定-->
				        </div>
					
					
						<!--logo-->
						<div class="row-top-logo">
						 <?php if ($this->options->logoUrl): ?>
								<a id="logo" href="<?php $this->options->siteUrl(); ?>">
						         <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>" />
						     </a>
						<?php else: ?>
						    <a id="logo" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
						    <p class="description"><?php $this->options->description() ?></p>
						<?php endif; ?>
						</div>
						
						<!--搜索框-->
						
						<input type="checkbox" id="dianji">
						      <label for="dianji" id="search-button">
						      </label>
							  
						<form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
							    <label for="s" class="sr-only"><?php _e('搜索关键字'); ?></label>
							    <input type="text" id="s" name="s" class="text" placeholder="<?php _e('输入关键字搜索'); ?>" />
							    <button type="submit" class="submit"><?php _e('搜索'); ?></button>
							</form>
										
			</div>
		 </div>
		 
		 
		 
            <div class="site-name col-mb-12 col-9">
			 <div class="row-top-content">
            <?php if ($this->options->logoUrl): ?>
							<a id="logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>" />
                </a>
           <?php else: ?>
               <a id="logo" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
               <p class="description"><?php $this->options->description() ?></p>
           <?php endif; ?>
		   </div>
		  <!-- 一言 -->
		  <div class="yiyan">
		  </br>
		   <script type="text/javascript" src="https://api.uixsj.cn/hitokoto/get?type=hitokoto&code=js"></script><div id="hitokoto"><script>hitokoto()</script></div>
		   </div>
		   </div>
            <div class="site-search col-3 kit-hidden-tb">
                <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
                    <label for="s" class="sr-only"><?php _e('搜索关键字'); ?></label>
                    <input type="text" id="s" name="s" class="text" placeholder="<?php _e('输入关键字搜索'); ?>" />
                    <button type="submit" class="submit"><?php _e('搜索'); ?></button>
					<div class="search-button-xbj">
						<span class="search-button-xbj-jz">加载用时:<?php echo timer_stop();?></span>
						<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
						<p>文章总数：<?php $stat->publishedPostsNum() ?>篇</p>
					</div>
                </form>
            </div>
            <div class="col-mb-12">
                <nav id="nav-menu" class="clearfix" role="navigation">
                    <a<?php if($this->is('index')): ?> class="current"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a>
                    <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                    <?php while($pages->next()): ?>
                    <a<?php if($this->is('page', $pages->slug)): ?> class="current"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
                    <?php endwhile; ?>
                </nav>
            </div>
        </div>
		<!-- end .row -->
    </div>
</header>
<!-- end #header -->
<div id="body">
    <div class="container">
        <div class="row">

    
    
