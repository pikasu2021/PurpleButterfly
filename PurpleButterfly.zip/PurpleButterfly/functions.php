<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function themeConfig($form) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点 LOGO 地址'), _t('在这里填入一个图片 URL 地址, 以在网站标题前加上一个 LOGO'));
    $form->addInput($logoUrl);
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    array('ShowRecentPosts' => _t('显示最新文章'),
    'ShowRecentComments' => _t('显示最近回复'),
    'ShowCategory' => _t('显示分类'),
    'ShowArchive' => _t('显示归档'),
    'ShowOther' => _t('显示其它杂项')),
    array('ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive', 'ShowOther'), _t('侧边栏显示'));
    
    $form->addInput($sidebarBlock->multiMode());
}


/*
function themeFields($layout) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO'));
    $layout->addItem($logoUrl);
}
*/

//当前作者文章数
function allpostnum($id){
$db = Typecho_Db::get();
$postnum=$db->fetchRow($db->select(array('COUNT(authorId)'=>'allpostnum'))->from ('table.contents')->where ('table.contents.authorId=?',$id)->where('table.contents.type=?', 'post'));
$postnum = $postnum['allpostnum'];
return $postnum;
}

//当前作者评论数
function allcommentsnum($name){
$db = Typecho_Db::get();

$commentnum=$db->fetchRow($db->select(array('COUNT(author)'=>'allcommentsnum'))->from ('table.comments')->where ('table.comments.author=?',$name));
//print_r($commentnum);
$commentnum = $commentnum['allcommentsnum'];
return $commentnum;
}

//文章字数统计
function  art_count ($cid){
$db=Typecho_Db::get ();
$rs=$db->fetchRow ($db->select ('table.contents.text')->from ('table.contents')->where ('table.contents.cid=?',$cid)->order ('table.contents.cid',Typecho_Db::SORT_ASC)->limit (1));
echo mb_strlen($rs['text'], 'UTF-8');
}

/** 输出文章缩略图 */
function img_postthumb($thumbThis) {
    $db = Typecho_Db::get();
    $rs = $db->fetchRow($db->select('table.contents.text')
        ->from('table.contents')
        ->where('table.contents.cid=?', $thumbThis->cid)
        ->order('table.contents.cid', Typecho_Db::SORT_ASC)
        ->limit(1));
    preg_match_all('/\<img.*?src\=\"(.*?)\"[^>]*>/i', $rs['text'], $thumbUrl);  //通过正则式获取图片地址
    preg_match_all('/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i', $rs['text'], $patternMD);  //通过正则式获取图片地址
    preg_match_all('/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i', $rs['text'], $patternMDfoot);  //通过正则式获取图片地址
    if(count($thumbUrl[0])>0){
        return $thumbUrl[1][0];  //当找到一个src地址的时候，输出缩略图
    }else if(count($patternMD[0])>0){
        return $patternMD[1][0];
    }else if(count($patternMDfoot[0])>0){
        return $patternMDfoot[1][0];
    }else{
        //在主题根目录下的 /img 目录下放随机图片 thumb_开头
        //如：thumb_1.jpg
        return $thumbThis->widget('Widget_Options')->themeUrl."/img/thumb_".rand(1,5).".jpg";
    }
}

/* 自定义首页文章分布数量，如 8 */
function themeInit($archive) {
if ($archive->is('index')) {
$archive->parameter->pageSize = 8;
}
}

    /**
     * 加载时间
     * @return bool
     */
    function timer_start() {
        global $timestart;
        $mtime     = explode( ' ', microtime() );
        $timestart = $mtime[1] + $mtime[0];
        return true;
    }
    timer_start();
    function timer_stop( $display = 0, $precision = 3 ) {
        global $timestart, $timeend;
        $mtime     = explode( ' ', microtime() );
        $timeend   = $mtime[1] + $mtime[0];
        $timetotal = number_format( $timeend - $timestart, $precision );
        $r         = $timetotal < 1 ? $timetotal * 1000 . " ms" : $timetotal . " s";
        if ( $display ) {
            echo $r;
        }
        return $r;
    }
	
	
//阅读次数
function get_post_view($archive){
	$cid    = $archive->cid;
	$db     = Typecho_Db::get();
	$prefix = $db->getPrefix();
	if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
		$db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
		echo 0;
		return;
	}
	$row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
	if ($archive->is('single')) {
 $views = Typecho_Cookie::get('extend_contents_views');
		if(empty($views)){
			$views = array();
		}else{
			$views = explode(',', $views);
		}
if(!in_array($cid,$views)){
	   $db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));
array_push($views, $cid);
			$views = implode(',', $views);
			Typecho_Cookie::set('extend_contents_views', $views); //记录查看cookie
		}
	}
	echo $row['views'];
}


//获取Gravatar头像 QQ邮箱取用qq头像
function getGravatar($email, $s = 96, $d = 'mp', $r = 'g', $img = false, $atts = array())
{
preg_match_all('/((\d)*)@qq.com/', $email, $vai);
if (empty($vai['1']['0'])) {
    $url = '/usr/themes/default/img/author-logo.png';
}else{
    $url = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$vai['1']['0'].'&spec=100';
}
return  $url;
}

function themeFields($layout) {
    $title = new Typecho_Widget_Helper_Form_Element_Text('title', NULL, NULL, _t('文章title标题'), _t('SEO设置'));
	$keywords = new Typecho_Widget_Helper_Form_Element_Text('keywords', NULL, NULL, _t('文章keywords关键词'), _t('SEO设置'));
	$description = new Typecho_Widget_Helper_Form_Element_Text('description', NULL, NULL, _t('文章description描述'), _t('SEO设置'));
    $layout->addItem($title);
	$layout->addItem($keywords);
	$layout->addItem($description);
}
